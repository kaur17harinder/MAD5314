//
//  ViewController.swift
//  WATCHOS
//
//  Created by MacStudent on 2019-02-26.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import UIKit
import WatchConnectivity

class ViewController: UIViewController, WCSessionDelegate{
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    func sessionDidBecomeInactive(_ session: WCSession) {
        
    }
    
    func sessionDidDeactivate(_ session: WCSession) {
        
    }
    
  func sendWatchMessages()
 {
    if (WCSession.default.isReachable) {
        // this is a nonsense message
        let message = ["Message": "Hello!"]
        WCSession.default.sendMessage(message, replyHandler: nil)
        print("message sent")
        outputLabel.text = "Message Sent"
    }
    else{
        outputLabel.text = "Phone not working"
    }
    
    }
    
    @IBAction func sendMessage(_ sender: Any) {
        print("clicked message sent")
        sendWatchMessages()
    }
    
    @IBOutlet weak var outputLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        if(WCSession.isSupported())
        {
            print("yes it is")
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
    }


}

