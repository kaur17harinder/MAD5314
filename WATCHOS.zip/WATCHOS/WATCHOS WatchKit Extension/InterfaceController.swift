//
//  InterfaceController.swift
//  WATCHOS WatchKit Extension
//
//  Created by MacStudent on 2019-02-26.
//  Copyright © 2019 MacStudent. All rights reserved.
//

import WatchKit
import Foundation
import WatchConnectivity


class InterfaceController: WKInterfaceController,WCSessionDelegate {
    
    func session(_ session: WCSession, activationDidCompleteWith activationState: WCSessionActivationState, error: Error?) {
        
    }
    
    var labelSaysHello: Bool = true
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        // Configure interface objects here.
    }
    
    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
        if WCSession.isSupported() {
            let session = WCSession.default
            session.delegate = self
            session.activate()
        }
        
    }
    
    
    func session(_ session: WCSession, didReceiveMessage message: [String : Any]) {
        //play click sound
        
        // Play a "click" sound when you get the message
        WKInterfaceDevice().play(.click)
        
        // output a debug message to the terminal
        print("Got a message! ")
        
        // update the message with a label
        messageLabel.setText("\(message)")

    }
    
    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

    @IBOutlet weak var messageLabel: WKInterfaceLabel!
    @IBAction func buttonClick() {
        
        print("PUSHED THE BUTTON")
       
        if(labelSaysHello == true)
        {
            messageLabel.setText("GOODBYE!")
            self.labelSaysHello = false
        }
        else
        {
            messageLabel.setText("HELLO")
            self.labelSaysHello = true
        }
    }
}
